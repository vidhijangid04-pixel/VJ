# Employee Attrition Dashboard

This repo contains app.py and EA.csv sample. Deploy on Streamlit Cloud.